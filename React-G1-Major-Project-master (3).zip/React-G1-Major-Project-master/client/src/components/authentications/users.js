import React from 'react'

export const users = () => {
    return (
        <div>
            Qusai
        </div>
    )
}
