import React from 'react';
import Dashboard from './Dashboard';
export default function Profile(){
    return(
        <div>
            <Dashboard/>
        </div>
    )
}
