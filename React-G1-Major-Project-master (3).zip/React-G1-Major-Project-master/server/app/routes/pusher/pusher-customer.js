var express = require('express');
var router = express.Router();

/* GET users listing. */
router.post('/auth', function(req, res, next) {

  const pusher = req.app.get('pusher');
  var currentCustomer = req.app.get('currentCustomer');
  const socketId = req.body.socket_id;
  
  console.log(currentCustomer);
  const channel = req.body.channel_name;
  console.log('channel-name ', channel)
  const presenseData = {
    user_id: socketId,
    name: "Kiran",
  };

  const auth = pusher.authenticate(socketId, channel, presenseData);
  req.app.set('currentCustomer',channel)
  //currentCustomer = channel;
  console.log('user ',req.app.get('currentCustomer'))
  
  res.send(auth);
});

module.exports = router;
